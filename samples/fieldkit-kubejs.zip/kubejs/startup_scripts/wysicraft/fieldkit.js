// Project helper: KubeJS globals must be defined at startup.
(() => { const API = Java.loadClass('com.wysicraft.runtime.api.WysicraftApi'); const id = "fieldkit"; global[id] = {open: player => API.openProject(player, id), close: player => API.closeProject(player, id)}; })();
