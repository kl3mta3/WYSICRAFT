// Generated WYSICRAFT server handlers. Install on the server; /reload after replacement.
(() => {
const API = Java.loadClass('com.wysicraft.runtime.api.WysicraftApi');
const projectId = "fieldkit";
API.clearKubeHandlers(projectId);

console.info('WYSICRAFT: registered 0 handlers for ' + projectId);
})();
