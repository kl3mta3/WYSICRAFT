// Generated WYSICRAFT server handlers. Install on the server; /reload after replacement.
(() => {
const API = Java.loadClass('com.wysicraft.runtime.api.WysicraftApi');
const projectId = "kube_bridge";
API.clearKubeHandlers(projectId);
(() => {
function on_click(event) {
  var clicks = Number(event.state.get('clicks') || 0) + 1;
  event.state.set('clicks', String(clicks));
  event.message('KubeJS received your WYSICRAFT click!');
  event.ui.setText('status', 'Server clicks: ' + clicks);
  event.runCommand('me tested the WYSICRAFT bridge');
  // Replace the command above with portal if your server provides it.
}

API.registerKubeHandler(projectId, "16f3334ae983d37dba52e5eb8c7e8b968d8354d7132afabae2c6e898459361dd", (context, value) => {
  const player = context.player();
  const ui = {setText: (id, text) => API.setText(player, id, String(text)), setValue: (id, value) => API.setValue(player, id, String(value)), setVisible: (id, visible) => API.setVisible(player, id, !!visible), setEnabled: (id, enabled) => API.setEnabled(player, id, !!enabled), setVariable: (name, value) => API.setVariable(player, name, String(value)), getVariable: name => context.state().get(String(name)), open: id => API.openUi(player, id), close: () => API.closeProject(player, projectId)};
  const event = {player: player, server: player.getServer(), value: String(context.state().getOrDefault('event_value', '')), ui: ui, runCommand: command => API.runCommand(player, String(command)), message: text => API.message(player, String(text)), state: {get: ui.getVariable, set: ui.setVariable}};
  on_click(event);
});
})();

console.info('WYSICRAFT: registered 1 handlers for ' + projectId);
})();
